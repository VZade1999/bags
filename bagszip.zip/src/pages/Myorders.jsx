import React, { useEffect, useState } from "react";
import { PostApi } from "../api/api";
import { jwtDecode } from "jwt-decode";
import Cookies from "js-cookie";
import { useNavigate, Link } from "react-router-dom";
import "../styles/myorders.css"; // Assuming you have a separate CSS file

const Myorders = () => {
  const navigate = useNavigate();
  const [myorderlist, setMyorderlist] = useState([]);

  useEffect(() => {
    const authCode = Cookies.get("authCode");
    if (!authCode) {
      navigate("/login");
      return;
    }

    const decodedToken = jwtDecode(authCode);

    const getMyOrders = async () => {
      try {
        const response = await PostApi(
          "/myorderlist",
          { useremail: decodedToken.email },
          true
        );

        setMyorderlist(response.data?.message.reverse() || []);
      } catch (error) {
        console.error("Error fetching orders:", error);
      }
    };

    getMyOrders();
  }, [navigate]);

  const handlePrint = (order) => {
    if (!order) return;

    const gstRate = 0.18;
    const subtotal = order.subtotal;
    const gstAmount = subtotal * gstRate;
    const totalPayment = subtotal + gstAmount;

    const printWindow = window.open("", "", "width=1600,height=900");
    const printContent = `<!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Order Invoice</title>
        <style>
          /* Add your invoice styles here */
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Order Invoice</h1>
        </div>
        <!-- Add the rest of your invoice content here -->
      </body>
      </html>
    `;

    printWindow.document.write(printContent);
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
  };

  return (
    <div className="myorders-container">
      <h4>Order List</h4>
      <div className="table-responsive">
        <table className="table table-striped">
          <thead>
            <tr>
              <th>#</th>
              <th>Order ID</th>
              <th>Item Name</th>
              <th>Quantity</th>
              <th>Price</th>
              <th>GST</th>
              <th>Delivery Charges</th>
              <th>Total</th>
              <th>Order Status</th>
              <th>Payment Status</th>
              <th>Invoice</th>
            </tr>
          </thead>
          <tbody>
            {myorderlist.length > 0 ? (
              myorderlist.map((order, index) => (
                <tr key={index}>
                  <td>{index + 1}</td>
                  <td>
                    <Link to={`/foods/${order._id}`} className="order-link">
                      {order._id || "N/A"}
                    </Link>
                  </td>
                  <td>
                    <Link
                      to={`/foods/${order.cartItems?.[0]?.id}`}
                      className="order-link"
                    >
                      {order.cartItems?.[0]?.title || "N/A"}
                    </Link>
                  </td>
                  <td>{order.cartItems?.[0]?.quantity || "N/A"}</td>
                  <td>{order.subtotal || "N/A"}</td>
                  <td>{order.GST || "N/A"}</td>
                  <td>{order.Shipping || "N/A"}</td>
                  <td>{order.totalAmount || "N/A"}</td>
                  <td
                    className={`order-status ${
                      order.status === "Order Rejected" ? "rejected" : ""
                    }`}
                  >
                    {order.status || "N/A"}
                  </td>
                  <td>
                    {order.payment?.hasOwnProperty("razorpay_payment_id")
                      ? "Completed"
                      : "Pending"}
                  </td>
                  <td>
                    {order.status !== "Order Rejected" && (
                      <svg
                        className="print-icon"
                        onClick={() => handlePrint(order)}
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth="1.5"
                        stroke="currentColor"
                        width="40"
                        height="40"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M6.72 13.829c-.24.03-.48.062-.72.096m.72-.096a42.415 42.415 0 0 1 10.56 0m-10.56 0L6.34 18m10.94-4.171c.24.03.48.062.72.096m-.72-.096L17.66 18m0 0 .229 2.523a1.125 1.125 0 0 1-1.12 1.227H7.231c-.662 0-1.18-.568-1.12-1.227L6.34 18m11.318 0h1.091A2.25 2.25 0 0 0 21 15.75V9.456c0-1.081-.768-2.015-1.837-2.175a48.055 48.055 0 0 0-1.913-.247M6.34 18H5.25A2.25 2.25 0 0 1 3 15.75V9.456c0-1.081.768-2.015 1.837-2.175a48.041 48.041 0 0 1 1.913-.247m10.5 0a48.536 48.536 0 0 0-10.5 0m10.5 0V3.375c0-.621-.504-1.125-1.125-1.125h-8.25c-.621 0-1.125.504-1.125 1.125v3.659M18 10.5h.008v.008H18V10.5Zm-3 0h.008v.008H15V10.5Z"
                        />
                      </svg>
                    )}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="11">No orders found.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Myorders;
